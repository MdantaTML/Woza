
import json
import os

DB_FILE = os.path.join(os.path.dirname(__file__), "data.json")

def save_data(entry):
    try:
        with open(DB_FILE, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        data = []
    data.append(entry)
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=2)

def get_data():
    try:
        with open(DB_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
