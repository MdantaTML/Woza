static V5 Bot Chk
